# Distributed Smart Campus Management System

A distributed, cloud-ready campus management platform built with **Spring Boot 3.2**, featuring IoT device integration, role-based access control, and modular microservice-ready architecture.

## Architecture

```
End Users (Student | Faculty | Admin | Parent)
        │
   Presentation Layer (React Web + Mobile)
        │
   API Gateway / Load Balancer
        │
   Auth + RBAC (JWT)
        │
   ┌────┴────┬────────────┬──────────────┐
Academic  Attendance   Library     Security
Service    Service     Service     Service
   │         │           │            │
   └────┬────┴─────┬─────┘            │
   MySQL Primary  MySQL Replica   MongoDB (IoT)
        │
   Cloud Infrastructure (AWS / Azure / GCP)
        │
   IoT Layer (RFID | Biometric | Sensors | CCTV)
```

## Modules

| Module | Description | Key Features |
|--------|-------------|-------------|
| **Academic** | Student, Faculty, Course, Enrollment management | CRUD operations, department filtering |
| **Attendance** | Smart attendance with IoT support | RFID/Biometric verification, summaries, date-range queries |
| **Library** | Book catalog + issue/return management | Search, availability tracking, overdue fines |
| **Security** | Surveillance & access logging | Event logging, alerts, severity filtering, location tracking |

## Tech Stack

- **Backend:** Java 17, Spring Boot 3.2, Spring Security, Spring Data JPA
- **Auth:** JWT (jjwt 0.12.5) with role-based access control
- **Database:** H2 (dev) / MySQL (prod) with replication support
- **IoT:** MQTT integration for sensor data
- **API Docs:** Swagger UI via springdoc-openapi
- **Monitoring:** Spring Actuator

## Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.0+ (for production)

### Run in Development Mode (H2)

```bash
cd smart-campus
mvn spring-boot:run
```

The app starts at `http://localhost:8080/api` with an in-memory H2 database.

### Access Points

| URL | Description |
|-----|-------------|
| `http://localhost:8080/api/swagger-ui.html` | Swagger UI |
| `http://localhost:8080/api/h2-console` | H2 Database Console |
| `http://localhost:8080/api/actuator/health` | Health Check |

### Run in Production Mode (MySQL)

1. Create the database:
```bash
mysql -u root -p < schema.sql
```

2. Set environment variables:
```bash
export DB_USERNAME=your_user
export DB_PASSWORD=your_password
```

3. Run with prod profile:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

## Test Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |
| Faculty | `drsmith` | `faculty123` |
| Faculty | `drjones` | `faculty123` |
| Student | `alice` | `student123` |
| Student | `bob` | `student123` |
| Student | `carol` | `student123` |
| Parent | `parent1` | `parent123` |

## API Endpoints

### Authentication
```
POST /api/auth/register    — Register new user
POST /api/auth/login       — Login (returns JWT)
```

### Academic Management
```
GET    /api/students                          — List all students
GET    /api/students/{id}                     — Get student by ID
GET    /api/students/department/{dept}         — Filter by department
GET    /api/faculty                           — List all faculty
GET    /api/courses                           — List all courses
POST   /api/courses                           — Create course (FACULTY/ADMIN)
PUT    /api/courses/{id}                      — Update course (FACULTY/ADMIN)
DELETE /api/courses/{id}                      — Delete course (ADMIN)
POST   /api/enrollments                       — Enroll student (STUDENT/ADMIN)
GET    /api/enrollments/student/{id}           — Student enrollments
GET    /api/enrollments/course/{id}            — Course enrollments (FACULTY/ADMIN)
```

### Attendance
```
POST /api/attendance                          — Mark attendance (FACULTY/ADMIN)
POST /api/attendance/iot/rfid                 — IoT RFID attendance
GET  /api/attendance/course/{id}/date/{date}  — By course + date
GET  /api/attendance/student/{id}/course/{id} — Student attendance in course
GET  /api/attendance/student/{id}/range       — By date range (?start=&end=)
GET  /api/attendance/summary/student/{id}/course/{id} — Attendance percentage
```

### Library
```
GET    /api/library/books                     — List all books
GET    /api/library/books/{id}                — Get book
GET    /api/library/books/search?keyword=     — Search books
GET    /api/library/books/available            — Available books
POST   /api/library/books                     — Add book (ADMIN)
PUT    /api/library/books/{id}                — Update book (ADMIN)
DELETE /api/library/books/{id}                — Delete book (ADMIN)
POST   /api/library/issues                    — Issue book (ADMIN/FACULTY)
PUT    /api/library/issues/{id}/return        — Return book
GET    /api/library/issues/student/{id}       — Student's issued books
GET    /api/library/issues/overdue            — Overdue books (ADMIN/FACULTY)
```

### Security & Surveillance
```
POST /api/security/logs                       — Log security event (ADMIN)
POST /api/security/alerts                     — Trigger alert (ADMIN)
GET  /api/security/logs                       — Recent 50 logs (ADMIN)
GET  /api/security/logs/{id}                  — Single log (ADMIN)
GET  /api/security/logs/type/{type}           — Filter by event type
GET  /api/security/logs/severity/{level}      — Filter by severity
GET  /api/security/logs/location/{location}   — Filter by location
GET  /api/security/logs/range?start=&end=     — Filter by date range
GET  /api/security/logs/user/{userId}         — User access history
```

## RBAC Permissions

| Action | STUDENT | FACULTY | ADMIN | PARENT |
|--------|---------|---------|-------|--------|
| View own data | ✅ | ✅ | ✅ | ✅ |
| Manage courses | ❌ | ✅ | ✅ | ❌ |
| Mark attendance | ❌ | ✅ | ✅ | ❌ |
| Issue/return books | ❌ | ✅ | ✅ | ❌ |
| Manage library catalog | ❌ | ❌ | ✅ | ❌ |
| Security logs | ❌ | ❌ | ✅ | ❌ |
| User management | ❌ | ❌ | ✅ | ❌ |

## Example API Usage

### Register + Login
```bash
# Register
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"newstudent","email":"new@campus.edu","password":"pass123","fullName":"New Student","role":"STUDENT"}'

# Login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

### Use JWT Token
```bash
TOKEN="your_jwt_token_here"

# Get all courses
curl http://localhost:8080/api/courses -H "Authorization: Bearer $TOKEN"

# Mark attendance via RFID
curl -X POST http://localhost:8080/api/attendance/iot/rfid \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"rfidTag":"RFID-001","deviceId":"READER-01","courseId":1}'
```

## Project Structure

```
smart-campus/
├── pom.xml
├── schema.sql
├── src/main/java/com/smartcampus/
│   ├── SmartCampusApplication.java
│   ├── config/
│   │   ├── SecurityConfig.java
│   │   └── DataInitializer.java
│   ├── controller/
│   │   ├── AuthController.java
│   │   ├── AcademicController.java
│   │   ├── AttendanceController.java
│   │   ├── LibraryController.java
│   │   └── SecurityController.java
│   ├── dto/
│   │   ├── AuthDto.java
│   │   ├── AcademicDto.java
│   │   ├── AttendanceDto.java
│   │   ├── LibraryDto.java
│   │   └── SecurityDto.java
│   ├── entity/
│   │   ├── Role.java
│   │   ├── User.java
│   │   ├── Student.java
│   │   ├── Faculty.java
│   │   ├── Course.java
│   │   ├── Enrollment.java
│   │   ├── Attendance.java
│   │   ├── LibraryBook.java
│   │   ├── BookIssue.java
│   │   └── SecurityLog.java
│   ├── exception/
│   │   ├── GlobalExceptionHandler.java
│   │   ├── ResourceNotFoundException.java
│   │   └── DuplicateResourceException.java
│   ├── repository/
│   │   ├── UserRepository.java
│   │   ├── StudentRepository.java
│   │   ├── FacultyRepository.java
│   │   ├── CourseRepository.java
│   │   ├── EnrollmentRepository.java
│   │   ├── AttendanceRepository.java
│   │   ├── LibraryBookRepository.java
│   │   ├── BookIssueRepository.java
│   │   └── SecurityLogRepository.java
│   ├── security/
│   │   ├── JwtTokenProvider.java
│   │   ├── JwtAuthenticationFilter.java
│   │   └── CustomUserDetailsService.java
│   └── service/
│       ├── AuthService.java
│       ├── AcademicService.java
│       ├── AttendanceService.java
│       ├── LibraryService.java
│       └── SecurityService.java
└── src/main/resources/
    ├── application.properties
    └── application-prod.properties
```
